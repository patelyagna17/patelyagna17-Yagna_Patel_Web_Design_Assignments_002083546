// server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUI = require('swagger-ui-express');
const userRoutes = require('./routes/userRoutes');
const { swaggerSpecs, swaggerUi } = require('./swagger'); 
const multer = require('multer'); // Import multer at the top

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/userdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));

// Swagger documentation
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'User Management API',
      version: '1.0.0',
      description: 'This is the documentation for the User API',
    },
    
  },
  apis: ['./routes/*.js'],
};

const specs = swaggerJSDoc(options);
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(specs));

// Routes
app.use('/user', userRoutes);

// Custom error handler
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Handle Multer errors
    return res.status(400).json({ error: err.message });
  }
  // Handle other errors
  res.status(500).json({ error: 'Invalid file format. Only JPEG, PNG, and GIF are allowed.' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});