// swagger.js
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'User API Documentation',
      version: '1.0.0',
      description: 'This is the documentation for the User API',
    },
    servers: [
      {
        url: 'http://localhost:3000',
      },
    ],
  },
  apis: ['./routes/userRoutes.js'], // Path to the API routes
};

const swaggerSpecs = swaggerJSDoc(options); // Renamed to avoid conflict

module.exports = {
  swaggerSpecs, // Export the renamed variable
  swaggerUi,
};