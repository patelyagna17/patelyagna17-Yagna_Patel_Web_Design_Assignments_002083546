// userController.js
const User = require('../models/User');
const bcrypt = require('bcrypt');

// Create a new user
exports.create = async (req, res) => {
  const { fullName, email, password } = req.body;

  // Validation
  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'Missing required fields.' });
  }

  if (!/^[a-zA-Z\s]*$/.test(fullName)) {
    return res.status(400).json({ error: 'Full name must contain only alphabetic characters.' });
  }

  if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
    return res.status(400).json({ error: 'Invalid email format.' });
  }

  if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
    return res.status(400).json({ error: 'Password does not meet the requirements.' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ fullName, email, password: hashedPassword });
    await newUser.save();
    res.status(201).json({ message: 'User created successfully.' });
  } catch (err) {
    res.status(400).json({ error: 'Validation failed.' });
  }
};

// Update user details
exports.update = async (req, res) => {
  const { fullName, password, email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Email is required.' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    if (fullName && !/^[a-zA-Z\s]*$/.test(fullName)) {
      return res.status(400).json({ error: 'Full name must contain only alphabetic characters.' });
    }

    if (password && !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
      return res.status(400).json({ error: 'Password does not meet the requirements.' });
    }

    if (fullName) {
      user.fullName = fullName;
    }

    if (password) {
      user.password = await bcrypt.hash(password, 10);
    }

    await user.save();
    res.status(200).json({ message: 'User updated successfully.' });
  } catch (err) {
    res.status(400).json({ error: 'Validation failed.' });
  }
};

// Delete user by email
exports.deleteById = async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOneAndDelete({ email });
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }
    res.status(200).json({ message: 'User deleted successfully.' });
  } catch (err) {
    res.status(404).json({ error: 'User not found.' });
  }
};

// userController.js
exports.getAll = async (req, res) => {
    try {
      const users = await User.find({}); // Include all fields
      res.status(200).json({ users });
    } catch (err) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
  
// userController.js
const fs = require('fs');
const path = require('path');

exports.uploadImage = async (req, res) => {
  const { email } = req.body;

  // Check if a file was uploaded
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }

  // Check file type
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
  if (!allowedTypes.includes(req.file.mimetype)) {
    // Delete the uploaded file
    fs.unlink(path.join(__dirname, '../images', req.file.filename), (err) => {
      if (err) {
        console.error('Error deleting file:', err);
      }
    });
    return res.status(400).json({ error: 'Invalid file format. Only JPEG, PNG, and GIF are allowed.' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      // Delete the uploaded file
      fs.unlink(path.join(__dirname, '../images', req.file.filename), (err) => {
        if (err) {
          console.error('Error deleting file:', err);
        }
      });
      return res.status(404).json({ error: 'User not found.' });
    }

    if (user.image) {
      // Delete the uploaded file
      fs.unlink(path.join(__dirname, '../images', req.file.filename), (err) => {
        if (err) {
          console.error('Error deleting file:', err);
        }
      });
      return res.status(400).json({ error: 'Image already exists for this user.' });
    }

    user.image = `/images/${req.file.filename}`;
    await user.save();
    res.status(201).json({ message: 'Image uploaded successfully.', filePath: user.image });
  } catch (err) {
    // Delete the uploaded file
    fs.unlink(path.join(__dirname, '../images', req.file.filename), (err) => {
      if (err) {
        console.error('Error deleting file:', err);
      }
    });
    res.status(500).json({ error: 'Invalid file format. Only JPEG, PNG, and GIF are allowed.' });
  }
};