// validators.js
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

exports.validateUser = (req, res, next) => {
  const { fullName, email, password } = req.body;

  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'Missing required fields.' });
  }

  if (!/^[a-zA-Z\s]*$/.test(fullName)) {
    return res.status(400).json({ error: 'Full name must contain only alphabetic characters.' });
  }

  if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
    return res.status(400).json({ error: 'Invalid email format.' });
  }

  if (!passwordRegex.test(password)) {
    return res.status(400).json({ error: 'Password does not meet the requirements.' });
  }

  next();
};

exports.validateUpdate = (req, res, next) => {
  const { fullName, password, email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Email is required.' });
  }

  if (password && !passwordRegex.test(password)) {
    return res.status(400).json({ error: 'Password does not meet the requirements.' });
  }

  if (fullName && !/^[a-zA-Z\s]*$/.test(fullName)) {
    return res.status(400).json({ error: 'Full name must contain only alphabetic characters.' });
  }

  next();
};

exports.validateImage = (req, res, next) => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }

  if (!allowedTypes.includes(req.file.mimetype)) {
    return res.status(400).json({ error: 'Invalid file format. Only JPEG, PNG, and GIF are allowed.' });
  }

  next();
};