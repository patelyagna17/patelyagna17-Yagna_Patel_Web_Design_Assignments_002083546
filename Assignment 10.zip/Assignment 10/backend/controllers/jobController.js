const Job = require('../models/Jobs');

exports.createJob = async (req, res) => {
  const { companyName, jobTitle, description, salary } = req.body;

  try {
    // Validate required fields
    if (!companyName || !jobTitle || !description || !salary) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required'
      });
    }

    // Validate salary is a positive number
    if (isNaN(salary) || salary <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Salary must be a positive number'
      });
    }

    const job = new Job({
      companyName,
      jobTitle,
      description,
      salary
    });

    await job.save();

    res.status(201).json({
      success: true,
      message: 'Job created successfully',
      data: job
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating job',
      error: error.message
    });
  }
};

exports.getAllJobs = async (req, res) => {
  try {
    const jobs = await Job.find()
      .sort({ createdAt: -1 }) // Sort by newest first
      .exec();

    res.status(200).json({
      success: true,
      message: 'Jobs retrieved successfully',
      data: jobs
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving jobs',
      error: error.message
    });
  }
};