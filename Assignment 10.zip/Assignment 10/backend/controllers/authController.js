const bcrypt = require('bcryptjs');
const User = require('../models/User');
const express = require("express");
const jwt = require('jsonwebtoken');

exports.loginUser = async (req, res) => {

    console.log(req.body);
    const { email, password } = req.body; 
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ isSuccess: false, message: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ isSuccess: false, message: "Invalid credentials" });
        }
        const token = jwt.sign(
            { userId: user._id, fullname: user.fullName },
            `jXuHCzo2vj4sf5QXKRVNijBmQp+uCQVbC20hzrZYtJTNulgeDX/Puibw5ch6as6fKIyrQHZ9QYS8XEikynZK8g==`,
            { expiresIn: '1h' } 
        );
        res.status(200).json({ isSuccess: true, message: "Successfully logged in", token: token, userRole:user.type });
    } catch (error) {
        res.status(500).json({ isSuccess: false, error: error.message });
    }
}