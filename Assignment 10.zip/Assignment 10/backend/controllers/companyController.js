const companyList = [
    { name: "Google", logo: "https://logo.clearbit.com/google.com", url: "https://www.google.com" },
    { name: "Facebook", logo: "https://logo.clearbit.com/facebook.com", url: "https://www.facebook.com" },
    { name: "Amazon", logo: "https://logo.clearbit.com/amazon.com", url: "https://www.amazon.com" },
    { name: "Apple", logo: "https://logo.clearbit.com/apple.com", url: "https://www.apple.com" },
    { name: "Microsoft", logo: "https://logo.clearbit.com/microsoft.com", url: "https://www.microsoft.com" },
    { name: "Netflix", logo: "https://logo.clearbit.com/netflix.com", url: "https://www.netflix.com" },
    { name: "Airbnb", logo: "https://logo.clearbit.com/airbnb.com", url: "https://www.airbnb.com" },
    { name: "Uber", logo: "https://logo.clearbit.com/uber.com", url: "https://www.uber.com" },
    { name: "Spotify", logo: "https://logo.clearbit.com/spotify.com", url: "https://www.spotify.com" },
    { name: "Twitter", logo: "https://logo.clearbit.com/twitter.com", url: "https://www.twitter.com" },
    { name: "LinkedIn", logo: "https://logo.clearbit.com/linkedin.com", url: "https://www.linkedin.com" },
    { name: "Snapchat", logo: "https://logo.clearbit.com/snapchat.com", url: "https://www.snapchat.com" },
    { name: "TikTok", logo: "https://logo.clearbit.com/tiktok.com", url: "https://www.tiktok.com" },
    { name: "Adobe", logo: "https://logo.clearbit.com/adobe.com", url: "https://www.adobe.com" },
    { name: "PayPal", logo: "https://logo.clearbit.com/paypal.com", url: "https://www.paypal.com" },
    { name: "Shopify", logo: "https://logo.clearbit.com/shopify.com", url: "https://www.shopify.com" },
    { name: "IBM", logo: "https://logo.clearbit.com/ibm.com", url: "https://www.ibm.com" },
    { name: "Intel", logo: "https://logo.clearbit.com/intel.com", url: "https://www.intel.com" },
    { name: "Samsung", logo: "https://logo.clearbit.com/samsung.com", url: "https://www.samsung.com" },
    { name: "Sony", logo: "https://logo.clearbit.com/sony.com", url: "https://www.sony.com" }
];

const companies = async (req, res) => {
    return res.status(200).json({
        "companies": companyList
    });
}

module.exports = { companies };