const bcrypt = require('bcryptjs');
const User = require('../models/User');

exports.createUser = async (req, res) => {
  const { fullName, email, password, type } = req.body;
  try {
    if (password.length < 6) {
      return res.status(400).json({ 
        success: false,
        message: 'Password must be at least 6 characters long' 
      });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered'
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ 
      fullName, 
      email, 
      password: hashedPassword,
      type
    });

    if (!type) {
      return res.status(401).json({
          success:false,
          message:'Role is required'
      })
  }

    await user.save();
    res.status(201).json({ 
      success: true,
      message: 'User created successfully',
      data: {
        fullName: user.fullName,
        email: user.email,
        type: user.type
      }
    });
  } catch (error) {
    res.status(500).json({ 
      success: false,
      message: 'Error creating user',
      error: error.message 
    });
  }
};

exports.updateUser = async (req, res) => {
  const { fullName, password } = req.body;
  const { email } = req.query;
  try {
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required in query parameters'
      });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (fullName) user.fullName = fullName;
    if (password) {
      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Password must be at least 6 characters long'
        });
      }
      user.password = await bcrypt.hash(password, 10);
    }

    await user.save();

    res.json({
      success: true,
      message: 'User updated successfully',
      data: {
        fullName: user.fullName,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating user',
      error: error.message
    });
  }
};

exports.deleteUser = async (req, res) => {
  const { email } = req.query;
  try {
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required in query parameters'
      });
    }

    const user = await User.findOneAndDelete({ email });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'User deleted successfully',
      data: {
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting user',
      error: error.message
    });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}, 'fullName email imagePath type')
      .select('-password') 
      .exec();

    res.json({
      success: true,
      message: 'Users retrieved successfully',
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving users',
      error: error.message
    });
  }
};

exports.uploadImage = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No image file uploaded' 
      });
    }

    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'User not found' 
      });
    }

    const imagePath = `/images/${req.file.filename}`;

    const updatedUser = await User.findOneAndUpdate(
      { email },
      { $set: { imagePath: imagePath } },
      { new: true }
    );

    res.status(200).json({
      success: true,
      message: 'Image uploaded successfully',
      data: {
        imagePath: updatedUser.imagePath,
        filename: req.file.filename,
        email: updatedUser.email
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error uploading image',
      error: error.message
    });
  }
};

exports.getUserByEmail = async (req, res) => {
  const { email } = req.query;
  try {
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required in query parameters'
      });
    }

    const user = await User.findOne({ email })
      .select('-password')
      .exec();

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'User retrieved successfully',
      data: user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving user',
      error: error.message
    });
  }
};