const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    match: [/.+\@.+\..+/, 'Please enter a valid email']
  },
  password: {
    type: String,
    required: true
  },
  type:{
    type:String,
    required:[true,'Role is required'],
    enum:{values:['admin','employee'], message:'Role must be either admin or employee'},
    lowercase:true,
    trim:true
},
  imagePath: {
    type: String,
    default: null
  }
});

module.exports = mongoose.model('User', userSchema);