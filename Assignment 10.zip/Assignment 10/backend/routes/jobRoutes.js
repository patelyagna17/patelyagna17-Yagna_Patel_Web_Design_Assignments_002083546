const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');

// Create job route
router.post('/job', jobController.createJob);

router.get('/getAll', jobController.getAllJobs);

module.exports = router;