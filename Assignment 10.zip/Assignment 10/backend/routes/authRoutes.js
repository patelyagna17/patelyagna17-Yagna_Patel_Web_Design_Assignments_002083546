
const express = require('express');
const multer = require('multer');
const path = require('path');
const {loginUser}= require('../controllers/authController');

const router = express.Router();
router.post('/login', loginUser);

module.exports = router;