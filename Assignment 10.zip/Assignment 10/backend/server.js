const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const companyRoutes = require('./routes/companyRoute');
const jobRoutes = require('./routes/jobRoutes')
const fs = require('fs');
const cors = require('cors');

const app = express();

app.use(cors());

const PORT = 3001;

const imagesDir = path.join(__dirname, 'images');
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir);
}

app.use(bodyParser.json());
app.use('/images', express.static('images'));

mongoose.connect('mongodb://localhost:27017/userdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch((error) => console.log(error));

app.use('/user', userRoutes);
app.use('/auth', authRoutes);
app.use('/companies', companyRoutes);
app.use('/create', jobRoutes)

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});