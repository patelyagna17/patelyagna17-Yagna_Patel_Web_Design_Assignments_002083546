import {
    CREATE_JOB_REQUEST,
    CREATE_JOB_SUCCESS,
    CREATE_JOB_FAILURE,
    FETCH_JOBS_REQUEST,
    FETCH_JOBS_SUCCESS,
    FETCH_JOBS_FAILURE,
    CLEAR_JOB_ERROR
  } from '../actions/jobActions';
  
  const initialState = {
    jobs: [],
    loading: false,
    error: null,
    createdJob: null
  };
  
  const jobReducer = (state = initialState, action) => {
    switch (action.type) {
      case CREATE_JOB_REQUEST:
      case FETCH_JOBS_REQUEST:
        return {
          ...state,
          loading: true,
          error: null
        };
        
      case CREATE_JOB_SUCCESS:
        return {
          ...state,
          loading: false,
          createdJob: action.payload,
          error: null
        };
        
      case FETCH_JOBS_SUCCESS:
        return {
          ...state,
          loading: false,
          jobs: action.payload,
          error: null
        };
        
      case CREATE_JOB_FAILURE:
      case FETCH_JOBS_FAILURE:
        return {
          ...state,
          loading: false,
          error: action.payload
        };
        
      case CLEAR_JOB_ERROR:
        return {
          ...state,
          error: null
        };
        
      default:
        return state;
    }
  };
  
  export default jobReducer;