import { combineReducers } from 'redux';
import employeeReducer from './employeeReducer';
import companyReducer from './companyReducer';
import jobReducer from './jobReducer';
import authReducer from './authReducer';

const rootReducer = combineReducers({
  employees: employeeReducer,
  companies: companyReducer,
  jobs: jobReducer,
  auth: authReducer
});

export default rootReducer;