import axios from 'axios';

//Action Types
export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const REGISTER_REQUEST = 'REGISTER_REQUEST';
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAILURE = 'REGISTER_FAILURE';
export const LOGOUT = 'LOGOUT';

// Action Creators
export const loginRequest = () => ({
  type: LOGIN_REQUEST
});

export const loginSuccess = (userData) => ({
  type: LOGIN_SUCCESS,
  payload: userData
});

export const loginFailure = (error) => ({
  type: LOGIN_FAILURE,
  payload: error
});

export const registerRequest = () => ({
  type: REGISTER_REQUEST
});

export const registerSuccess = () => ({
  type: REGISTER_SUCCESS
});

export const registerFailure = (error) => ({
  type: REGISTER_FAILURE,
  payload: error
});

export const logout = () => ({
  type: LOGOUT
});


// Thunk Action Creator
export const login = (credentials) => async (dispatch, getState) => {
  dispatch(loginRequest());
  try {
    const response = await axios.post('http://localhost:3001/auth/login', credentials);
    if (response.data.isSuccess) {
      const userData = {
        isLoggedIn: true,
        userRole: response.data.userRole
      };
      dispatch(loginSuccess(userData));
      return {
        success: true,
        userRole: response.data.userRole,
        data: response.data
      };
    } else {
      dispatch(loginFailure(response.data.message));
      return { success: false, message: response.data.message };
    }
  } catch (error) {
    const errorMessage = error.response?.data?.message || 'Login failed. Please try again.';
    dispatch(loginFailure(errorMessage));
    return { success: false, message: errorMessage };
  }
};

export const register = (userData) => async (dispatch) => {
  dispatch(registerRequest());
  try {
    const response = await axios.post('http://localhost:3001/user/create', userData);
    if (response.data.success) {
      dispatch(registerSuccess());
      return { success: true };
    } else {
      dispatch(registerFailure(response.data.message));
      return { success: false, error: response.data.message };
    }
  } catch (error) {
    const errorMessage = error.response?.data?.message || 'Registration failed. Please try again.';
    dispatch(registerFailure(errorMessage));
    return { success: false, error: errorMessage };
  }
};