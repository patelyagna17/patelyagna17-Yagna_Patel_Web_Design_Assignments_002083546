import axios from 'axios';

// Action Types
export const CREATE_JOB_REQUEST = 'CREATE_JOB_REQUEST';
export const CREATE_JOB_SUCCESS = 'CREATE_JOB_SUCCESS';
export const CREATE_JOB_FAILURE = 'CREATE_JOB_FAILURE';
export const FETCH_JOBS_REQUEST = 'FETCH_JOBS_REQUEST';
export const FETCH_JOBS_SUCCESS = 'FETCH_JOBS_SUCCESS';
export const FETCH_JOBS_FAILURE = 'FETCH_JOBS_FAILURE';
export const CLEAR_JOB_ERROR = 'CLEAR_JOB_ERROR';

// Action Creators
export const createJobRequest = () => ({
  type: CREATE_JOB_REQUEST
});

export const createJobSuccess = (job) => ({
  type: CREATE_JOB_SUCCESS,
  payload: job
});

export const createJobFailure = (error) => ({
  type: CREATE_JOB_FAILURE,
  payload: error
});

export const fetchJobsRequest = () => ({
  type: FETCH_JOBS_REQUEST
});

export const fetchJobsSuccess = (jobs) => ({
  type: FETCH_JOBS_SUCCESS,
  payload: jobs
});

export const fetchJobsFailure = (error) => ({
  type: FETCH_JOBS_FAILURE,
  payload: error
});

export const clearJobError = () => ({
  type: CLEAR_JOB_ERROR
});

// Thunk Action Creator for creating a job
export const createJob = (jobData) => async (dispatch) => {
  dispatch(createJobRequest());
  try {
    const response = await axios.post('http://localhost:3001/create/job', jobData);
    if (response.data.success) {
      dispatch(createJobSuccess(response.data.data));
      return { success: true };
    } else {
      dispatch(createJobFailure(response.data.message));
      return { success: false, error: response.data.message };
    }
  } catch (error) {
    const errorMessage = error.response?.data?.message || 'Error creating job listing';
    dispatch(createJobFailure(errorMessage));
    return { success: false, error: errorMessage };
  }
};

// Thunk Action Creator for fetching jobs
export const fetchJobs = () => async (dispatch) => {
  dispatch(fetchJobsRequest());
  try {
    const response = await axios.get('http://localhost:3001/create/getAll');
    if (response.data.success) {
      dispatch(fetchJobsSuccess(response.data.data));
    } else {
      dispatch(fetchJobsFailure('Failed to fetch jobs'));
    }
  } catch (error) {
    dispatch(fetchJobsFailure('Error connecting to the server'));
  }
};