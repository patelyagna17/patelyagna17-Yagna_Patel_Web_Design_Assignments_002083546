import axios from 'axios';

// Action Types
export const FETCH_EMPLOYEES_REQUEST = 'FETCH_EMPLOYEES_REQUEST';
export const FETCH_EMPLOYEES_SUCCESS = 'FETCH_EMPLOYEES_SUCCESS';
export const FETCH_EMPLOYEES_FAILURE = 'FETCH_EMPLOYEES_FAILURE';

// Action Creators
export const fetchEmployeesRequest = () => ({
  type: FETCH_EMPLOYEES_REQUEST
});

export const fetchEmployeesSuccess = (employees) => ({
  type: FETCH_EMPLOYEES_SUCCESS,
  payload: employees
});

export const fetchEmployeesFailure = (error) => ({
  type: FETCH_EMPLOYEES_FAILURE,
  payload: error
});

// Thunk Action Creator
export const fetchEmployees = () => {
  return async (dispatch) => {
    dispatch(fetchEmployeesRequest());
    try {
      const response = await axios.get('http://localhost:3001/user/getAll');
      if (response.data.success) {
        dispatch(fetchEmployeesSuccess(response.data.data));
      } else {
        dispatch(fetchEmployeesFailure(response.data.message));
      }
    } catch (error) {
      dispatch(fetchEmployeesFailure(error.message));
    }
  };
};