import axios from 'axios';

// Action Types
export const FETCH_COMPANIES_REQUEST = 'FETCH_COMPANIES_REQUEST';
export const FETCH_COMPANIES_SUCCESS = 'FETCH_COMPANIES_SUCCESS';
export const FETCH_COMPANIES_FAILURE = 'FETCH_COMPANIES_FAILURE';

// Action Creators
export const fetchCompaniesRequest = () => ({
  type: FETCH_COMPANIES_REQUEST
});

export const fetchCompaniesSuccess = (companies) => ({
  type: FETCH_COMPANIES_SUCCESS,
  payload: companies
});

export const fetchCompaniesFailure = (error) => ({
  type: FETCH_COMPANIES_FAILURE,
  payload: error
});

// Thunk Action Creator
export const fetchCompanies = () => {
  return async (dispatch) => {
    dispatch(fetchCompaniesRequest());
    try {
      const response = await axios.get('http://localhost:3001/companies/');
      dispatch(fetchCompaniesSuccess(response.data.companies));
    } catch (error) {
      dispatch(fetchCompaniesFailure(error.message));
    }
  };
};