import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // ensures that the app is using the best practices and is future-proof
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

