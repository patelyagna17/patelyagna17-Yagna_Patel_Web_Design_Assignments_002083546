import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './redux/store';
import Home from './components/Home';
import About from './components/About'; 
import Navbar from './components/Navbar';
import Contact from './components/Contact';
import Companies from './components/Companies';
import JobListings from './components/JobListings';
import Login from './components/Login';
import Footer from './components/Footer';
import React from 'react';
import Register from './components/Register';
import Employees from './components/Employees';
import AddJob from './components/AddJob';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem('isLoggedIn') === 'true');
  const [userRole, setUserRole] = useState(() => localStorage.getItem('userRole') || '');

  // Protect admin routes
  const AdminRoute = ({ children }) => {
    if (userRole !== 'admin') {
      return <Navigate to="/home" replace />;
    }
    return children;
  };

  const UserRoute = ({ children }) => {
    if (userRole !== 'employee') {
      return <Navigate to={userRole === 'admin' ? '/employees' : '/login'} replace />;
    }
    return children;
  };

  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/register" element={<Register setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} setUserRole={setUserRole} />} />
          <Route path="/" element={
            isLoggedIn ? (
              <div>
                <Navbar setIsLoggedIn={setIsLoggedIn} userRole={userRole} />
                <Outlet />
                <Footer />
              </div>
            ) : (
              <Navigate replace to="/login" />
            )
          }>
            {/* User Only Routes */}
            <Route path="home" element={
              <UserRoute>
                <Home />
              </UserRoute>
            } />
            <Route path="about" element={
              <UserRoute>
                <About />
              </UserRoute>
            } />
            <Route path="contact" element={
              <UserRoute>
                <Contact />
              </UserRoute>
            } />
            <Route path="companies" element={
              <UserRoute>
                <Companies />
              </UserRoute>
            } />
            <Route path="joblistings" element={
              <UserRoute>
                <JobListings />
              </UserRoute>
            } />
          
            {/* Admin Only Routes */}
            <Route path="employees" element={
              <AdminRoute>
                <Employees />
              </AdminRoute>
            } />
            <Route path="addjobs" element={
              <AdminRoute>
                <AddJob />
              </AdminRoute>
            } />
          </Route>
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;