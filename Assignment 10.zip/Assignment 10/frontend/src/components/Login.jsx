import React, { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import { login } from "../redux/actions/authActions"
import {
  Typography,
  Box,
  TextField,
  Button,
  Container,
  Paper,
  CircularProgress,
} from "@mui/material"

function Login({ setIsLoggedIn, setUserRole }) {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { loading, error } = useSelector((state) => state.auth)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const onLogin = async (e) => {
    e.preventDefault()

    try {
      const result = await dispatch(login({ email, password }))

      if (result.success) {
        setIsLoggedIn(true)
        setUserRole(result.userRole)
        localStorage.setItem("isLoggedIn", true)
        localStorage.setItem("userRole", result.userRole)

        if (result.userRole === "admin") {
          navigate("/employees")
        } else {
          navigate("/home")
        }
      } else {
        alert(result.message)
      }
    } catch (error) {
      alert("Login failed. Please try again.")
    }
  }

  return (
    <Box sx={{ backgroundColor: "#f5fff5", minHeight: "100vh", display: "flex", alignItems: "center" }}>
      <Container maxWidth="sm">
        <Paper
          elevation={4}
          sx={{
            px: 5,
            py: 6,
            borderRadius: 3,
            backgroundColor: "#ffffff",
            boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
          }}
        >
          <Typography
            component="h1"
            variant="h3"
            align="center"
            sx={{ mb: 3, color: "#1b5e20", fontWeight: "bold" }}
          >
            JobPortal
          </Typography>
          <Typography
            variant="h6"
            align="center"
            sx={{ color: "#2e7d32", mb: 4 }}
          >
            Welcome to Growth.
          </Typography>

          <Box component="form" onSubmit={onLogin}>
            <TextField
              label="Email"
              variant="outlined"
              required
              fullWidth
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />
            <TextField
              label="Password"
              type="password"
              variant="outlined"
              required
              fullWidth
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />

            {error && (
              <Typography variant="body2" sx={{ color: "#f44336", mb: 2 }}>
                {error}
              </Typography>
            )}

            <Box sx={{ position: "relative" }}>
              <Button
                type="submit"
                variant="contained"
                fullWidth
                disabled={loading}
                sx={{
                  backgroundColor: "#2e7d32",
                  py: 1.5,
                  fontWeight: 600,
                  "&:hover": {
                    backgroundColor: "#1b5e20",
                  },
                }}
              >
                {loading ? "Logging in..." : "Login"}
              </Button>
              {loading && (
                <CircularProgress
                  size={24}
                  sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    marginTop: "-12px",
                    marginLeft: "-12px",
                    color: "#2e7d32",
                  }}
                />
              )}
            </Box>

            <Button
              variant="text"
              fullWidth
              onClick={() => navigate("/register")}
              disabled={loading}
              sx={{ mt: 2, color: "#2e7d32", fontWeight: 500 }}
            >
              Don’t have an account? Register here
            </Button>
          </Box>
        </Paper>
      </Container>
    </Box>
  )
}

export default Login
