// /** @jsx jsx */
// /** @jsxRuntime classic */
// import { jsx } from '@emotion/react'
// import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchCompanies } from '../redux/actions/companyActions';
// import { 
//   Card, 
//   CardActionArea, 
//   CardMedia, 
//   CardContent, 
//   Typography, 
//   Grid, 
//   CircularProgress 
// } from '@mui/material';

// const styles = () => ({
//   '.cardStyling': {
//     padding: '10px',
//     margin: '30px',
//     border: '1px solid #ccc',
//     borderRadius: '15px',
//   },
//   '.company_name': {
//     textAlign: 'center',
//     fontSize: '30px',
//     fontWeight: 'bold',
//     padding: '5px'
//   },
//   '.loadingContainer': {
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     minHeight: '60vh',
//     width: '100%'
//   },
//   '.errorMessage': {
//     textAlign: 'center',
//     color: 'red',
//     width: '100%',
//     padding: '20px'
//   }
// });

// function Companies() {
//   const dispatch = useDispatch();
//   const { companies, loading, error } = useSelector(state => state.companies);

//   useEffect(() => {
//     dispatch(fetchCompanies());
//   }, [dispatch]);

//   if (loading) {
//     return (
//       <div css={styles()}>
//         <div className="loadingContainer">
//           <CircularProgress />
//         </div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div css={styles()}>
//         <Typography className="errorMessage" variant="h6">
//           {error}
//         </Typography>
//       </div>
//     );
//   }

//   return (
//     <Grid css={styles()} container spacing={4}>
//       {companies.map((company, index) => (
//         <Grid item xs={12} sm={6} md={4} key={index}>
//           <Card className='cardStyling'>
//             <CardActionArea href={company.url}>
//               <CardMedia
//                 component="img"
//                 image={company.logo}
//                 alt={`${company.name} Logo`}
//                 sx={{
//                   height: 180,
//                   objectFit: 'contain',
//                 }}
//               />
//               <CardContent>
//                 <Typography className="company_name" variant="h5" component="div">
//                   {company.name}
//                 </Typography>
//               </CardContent>
//             </CardActionArea>
//           </Card>
//         </Grid>
//       ))}
//       {companies.length === 0 && !loading && !error && (
//         <Typography 
//           style={{ width: '100%', textAlign: 'center', padding: '20px' }}
//         >
//           No companies found
//         </Typography>
//       )}
//     </Grid>
//   );
// }

// export default Companies;
"use client"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { fetchCompanies } from "../redux/actions/companyActions"
import {
  Card,
  CardActionArea,
  CardMedia,
  CardContent,
  Typography,
  Grid,
  CircularProgress,
  Box,
} from "@mui/material"

function Companies() {
  const dispatch = useDispatch()
  const { companies, loading, error } = useSelector((state) => state.companies)

  useEffect(() => {
    dispatch(fetchCompanies())
  }, [dispatch])

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "60vh",
          backgroundColor: "#f5fff5",
        }}
      >
        <CircularProgress sx={{ color: "#2e7d32" }} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box
        sx={{
          textAlign: "center",
          padding: 4,
          backgroundColor: "#f5fff5",
        }}
      >
        <Typography variant="h6" sx={{ color: "#f44336" }}>
          {error}
        </Typography>
      </Box>
    )
  }

  return (
    <Box sx={{ flexGrow: 1, backgroundColor: "#f5fff5", padding: 4, minHeight: "100vh" }}>
      <Grid container spacing={4} justifyContent="center">
        {companies.map((company, index) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
            <Card
              sx={{
                padding: 2,
                border: "1px solid #a5d6a7",
                borderRadius: 3,
                backgroundColor: "#e8f5e9",
                height: "100%",
              }}
            >
              <CardActionArea href={company.url}>
                <CardMedia
                  component="img"
                  image={company.logo}
                  alt={`${company.name} Logo`}
                  sx={{
                    height: 180,
                    objectFit: "contain",
                    mb: 2,
                  }}
                />
                <CardContent>
                  <Typography
                    variant="h6"
                    sx={{
                      textAlign: "center",
                      color: "#1b5e20",
                      fontWeight: "bold",
                    }}
                  >
                    {company.name}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
        {companies.length === 0 && !loading && !error && (
          <Typography
            sx={{
              width: "100%",
              textAlign: "center",
              padding: 4,
              color: "#2e7d32",
            }}
          >
            No companies found
          </Typography>
        )}
      </Grid>
    </Box>
  )
}

export default Companies
