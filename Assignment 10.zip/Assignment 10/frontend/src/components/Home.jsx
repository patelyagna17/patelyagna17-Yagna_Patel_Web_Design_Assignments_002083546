// import React from 'react';
// import { Typography, Button, TextField, Box,  } from '@mui/material';
// import WorkIcon from '@mui/icons-material/Work';
// import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';


// function Home() {
//   return (
    
//     <Box sx={{ flexGrow: 1, padding: 2 }}>
     

//       {/* Main Section */}
//       <Box sx={{ my: 4 }}>
//         <Typography variant="h2" >
//           Welcome to JobPortal
//         </Typography>
//         <Typography variant="h5" >
//           "Your bridge to a brighter future. Find your dream job or discover the perfect candidate today."
//         </Typography>

//         {/* Search Bar */}
//         <Box sx={{ my: 2 }}>
//           <TextField fullWidth label="Search over 10,000 job listings"  />
//         </Box>
//    {/* Buttons */}
//    <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', my: 5 }}>
//               <Button variant="contained" color="primary" startIcon={<WorkIcon />}>
//                 I'm looking for a job
//               </Button>
//               <Button variant="outlined" color="primary" startIcon={<BusinessCenterIcon />}>
//                 I'm looking to hire
//               </Button>
//             </Box>
//           </Box>

 

//       {/* Testimonials */}
//       <Typography variant="body1"  sx={{ my: 2 }}>
//       "Thanks to JobPortal, I secured my dream job within just two weeks! - Samuel S."
//       </Typography>
//       <Typography variant="body1" sx={{ my: 2 }}>
//   "Finding the right candidate was a breeze with JobPortal. The quality of applicants was outstanding. - Aly L."
// </Typography>

// <Typography variant="body1" sx={{ my: 2 }}>
//   "JobPortal's intuitive design made job hunting less stressful and more productive. Highly recommend! - Samir A."
// </Typography>

// <Typography variant="body1" sx={{ my: 2 }}>
//   "I never thought I could switch car"At 40, I didn't think a career change was possible, but JobPortal made it happen by connecting me with an entry-level opportunity in a new industry. - Jay B."
// </Typography>

// <Typography variant="body1" sx={{ my: 2 }}>
//   "As a small business owner, finding the right talent is challenging. JobPortal connected me with incredible professionals. - Ella G."
// </Typography>

// <Typography variant="body1" sx={{ my: 2 }}>
//   "JobPortal streamlined our hiring process, making it easy to manage applications and communicate with candidates. - Omar D."
// </Typography>


      
//     </Box>
//   );
// }

// export default Home;
import { Typography, Button, TextField, Box, Paper } from "@mui/material"
import WorkIcon from "@mui/icons-material/Work"
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter"

function Home() {
  const testimonials = [
    {
      author: "Kirti",
      text: "Within two weeks, JobPortal connected me to a role I absolutely love. The process was smooth and stress-free!"
    },
    {
      author: "Prakash",
      text: "We found the perfect candidate faster than we expected. JobPortal brought in top-tier applicants right away."
    },
    {
      author: "Rekha",
      text: "Job searching felt effortless thanks to JobPortal’s intuitive design. I highly recommend it to anyone looking for a career move."
    },
    {
      author: "Ruchi",
      text: "Changing careers at 40 felt overwhelming, but JobPortal made it possible with opportunities I never imagined."
    },
    {
      author: "Sampada",
      text: "As a small business owner, hiring has always been tough. JobPortal introduced me to exceptional professionals easily."
    },
    {
      author: "Mahu",
      text: "From managing applications to messaging candidates, JobPortal simplified every part of the hiring process for us."
    }
  ]

  return (
    <Box sx={{ flexGrow: 1, padding: 4, backgroundColor: "#f5fff5", minHeight: "100vh" }}>
      {/* Header Section */}
      <Box sx={{ textAlign: "center", my: 6 }}>
        <Typography variant="h2" sx={{ color: "#1b5e20", fontWeight: "bold" }}>
          Welcome to Growth
        </Typography>
        <Typography variant="h6" sx={{ color: "#2e7d32", mt: 2 }}>
        Connecting you to rewarding careers and exceptional talent — let's find your perfect fit together."
        </Typography>
      </Box>

      {/* Search Bar */}
      <Box sx={{ maxWidth: 600, mx: "auto", my: 4 }}>
        <TextField
          fullWidth
          label="Search from thousands of job opportunities"
          variant="outlined"
          sx={{
            "& .MuiOutlinedInput-root": {
              "&.Mui-focused fieldset": {
                borderColor: "#2e7d32",
              },
            },
            "& .MuiInputLabel-root.Mui-focused": {
              color: "#2e7d32",
            },
          }}
        />
      </Box>

      {/* Action Buttons */}
      <Box sx={{ display: "flex", justifyContent: "center", gap: 3, my: 4 }}>
        <Button
          variant="contained"
          sx={{
            backgroundColor: "#2e7d32",
            paddingX: 3,
            "&:hover": { backgroundColor: "#1b5e20" },
          }}
          startIcon={<WorkIcon />}
        >
          Find a Job
        </Button>
        <Button
          variant="outlined"
          sx={{
            color: "#2e7d32",
            borderColor: "#2e7d32",
            paddingX: 3,
            "&:hover": {
              borderColor: "#1b5e20",
              backgroundColor: "rgba(46, 125, 50, 0.04)",
            },
          }}
          startIcon={<BusinessCenterIcon />}
        >
          Hire Talent
        </Button>
      </Box>

      {/* Testimonials Section */}
      <Box sx={{ mt: 6 }}>
        <Typography variant="h5" sx={{ color: "#1b5e20", fontWeight: 600, mb: 3 }}>
          What Our Users Say
        </Typography>

        {testimonials.map((item, index) => (
          <Paper
            key={index}
            elevation={1}
            sx={{ p: 2, my: 2, backgroundColor: "#f1f8e9", borderLeft: "6px solid #2e7d32" }}
          >
            <Typography variant="body1" sx={{ color: "#33691e" }}>
              "{item.text}"
            </Typography>
            <Typography variant="subtitle2" sx={{ mt: 1, textAlign: "right", fontStyle: "italic", color: "#558b2f" }}>
              - {item.author}
            </Typography>
          </Paper>
        ))}
      </Box>
    </Box>
  )
}

export default Home
