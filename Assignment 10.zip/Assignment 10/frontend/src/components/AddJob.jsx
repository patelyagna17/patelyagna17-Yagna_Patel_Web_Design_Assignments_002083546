// /** @jsx jsx */
// /** @jsxRuntime classic */
// import { jsx } from '@emotion/react';
// import React, { useState, useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { createJob, clearJobError } from '../redux/actions/jobActions';
// import { Card, Typography, TextField, Button, CircularProgress } from '@mui/material';
// import { useNavigate } from 'react-router-dom';

// const styles = {
//   container: {
//     margin: '0 auto',
//     maxWidth: '800px',
//     padding: '20px',
//     backgroundColor: '#f0f0f0',
//     borderRadius: '8px',
//     boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
//   },
//   formCard: {
//     padding: '20px',
//     borderRadius: '15px',
//     marginBottom: '25px',
//     backgroundColor: '#fff',
//   },
//   title: {
//     fontSize: '24px',
//     color: '#333',
//     margin: '0 0 20px 0',
//   },
//   field: {
//     marginBottom: '20px',
//     width: '100%',
//   },
//   submitButton: {
//     backgroundColor: '#007bff',
//     color: '#fff',
//     '&:hover': {
//       backgroundColor: '#0056b3',
//     },
//   },
//   errorMessage: {
//     color: '#ff0000',
//     marginBottom: '10px',
//   },
//   loadingWrapper: {
//     position: 'relative',
//   },
//   buttonProgress: {
//     position: 'absolute',
//     top: '50%',
//     left: '50%',
//     marginTop: -12,
//     marginLeft: -12,
//   }
// };

// function AddJob() {
//   const navigate = useNavigate();
//   const dispatch = useDispatch();
//   const { loading, error } = useSelector(state => state.jobs);

//   const [formData, setFormData] = useState({
//     companyName: '',
//     jobTitle: '',
//     description: '',
//     salary: ''
//   });

//   useEffect(() => {
//     return () => {
//       dispatch(clearJobError());
//     };
//   }, [dispatch]);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData(prevState => ({
//       ...prevState,
//       [name]: value
//     }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     const jobData = {
//       ...formData,
//       salary: Number(formData.salary)
//     };

//     const result = await dispatch(createJob(jobData));
    
//     if (result.success) {
//       alert('Job posted successfully!');
//       navigate('/joblistings');
//     }
//   };

//   return (
//     <div css={styles.container}>
//       <Typography variant="h4" css={styles.title}>Add New Job</Typography>
//       <Card css={styles.formCard}>
//         <form onSubmit={handleSubmit}>
//           <TextField
//             label="Company Name"
//             name="companyName"
//             variant="outlined"
//             required
//             css={styles.field}
//             value={formData.companyName}
//             onChange={handleChange}
//             disabled={loading}
//           />
          
//           <TextField
//             label="Job Title"
//             name="jobTitle"
//             variant="outlined"
//             required
//             css={styles.field}
//             value={formData.jobTitle}
//             onChange={handleChange}
//             disabled={loading}
//           />
          
//           <TextField
//             label="Description"
//             name="description"
//             variant="outlined"
//             required
//             multiline
//             rows={4}
//             css={styles.field}
//             value={formData.description}
//             onChange={handleChange}
//             disabled={loading}
//           />
          
//           <TextField
//             label="Salary"
//             name="salary"
//             type="number"
//             variant="outlined"
//             required
//             css={styles.field}
//             value={formData.salary}
//             onChange={handleChange}
//             disabled={loading}
//             InputProps={{
//               inputProps: { min: 0 }
//             }}
//           />

//           {error && (
//             <Typography css={styles.errorMessage}>
//               {error}
//             </Typography>
//           )}

//           <div css={styles.loadingWrapper}>
//             <Button 
//               type="submit"
//               variant="contained"
//               fullWidth
//               css={styles.submitButton}
//               disabled={loading}
//             >
//               {loading ? 'Posting Job...' : 'Post Job'}
//             </Button>
//             {loading && (
//               <CircularProgress size={24} css={styles.buttonProgress} />
//             )}
//           </div>
//         </form>
//       </Card>
//     </div>
//   );
// }

// export default AddJob;

"use client"
import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { createJob, clearJobError } from "../redux/actions/jobActions"
import {
  Box,
  Card,
  Typography,
  TextField,
  Button,
  CircularProgress,
  Container,
} from "@mui/material"
import { useNavigate } from "react-router-dom"

function AddJob() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { loading, error } = useSelector((state) => state.jobs)

  const [formData, setFormData] = useState({
    companyName: "",
    jobTitle: "",
    description: "",
    salary: "",
  })

  useEffect(() => {
    return () => {
      dispatch(clearJobError())
    }
  }, [dispatch])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const jobData = {
      ...formData,
      salary: Number(formData.salary),
    }

    const result = await dispatch(createJob(jobData))

    if (result.success) {
      alert("Job posted successfully!")
      navigate("/joblistings")
    }
  }

  return (
    <Box sx={{ backgroundColor: "#f5fff5", minHeight: "100vh", py: 6 }}>
      <Container maxWidth="md">
        <Typography
          variant="h4"
          sx={{
            color: "#1b5e20",
            fontWeight: "bold",
            textAlign: "center",
            mb: 4,
          }}
        >
          Post a New Job
        </Typography>

        <Card
          sx={{
            padding: 4,
            backgroundColor: "#ffffff",
            borderRadius: 3,
            boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
          }}
        >
          <form onSubmit={handleSubmit}>
            <TextField
              label="Company Name"
              name="companyName"
              variant="outlined"
              required
              fullWidth
              value={formData.companyName}
              onChange={handleChange}
              disabled={loading}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />

            <TextField
              label="Job Title"
              name="jobTitle"
              variant="outlined"
              required
              fullWidth
              value={formData.jobTitle}
              onChange={handleChange}
              disabled={loading}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />

            <TextField
              label="Job Description"
              name="description"
              variant="outlined"
              required
              multiline
              rows={4}
              fullWidth
              value={formData.description}
              onChange={handleChange}
              disabled={loading}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />

            <TextField
              label="Salary ($)"
              name="salary"
              type="number"
              variant="outlined"
              required
              fullWidth
              value={formData.salary}
              onChange={handleChange}
              disabled={loading}
              InputProps={{
                inputProps: { min: 0 },
              }}
              sx={{
                mb: 3,
                "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />

            {error && (
              <Typography sx={{ color: "#f44336", mb: 2 }}>
                {error}
              </Typography>
            )}

            <Box sx={{ position: "relative" }}>
              <Button
                type="submit"
                variant="contained"
                fullWidth
                disabled={loading}
                sx={{
                  backgroundColor: "#2e7d32",
                  color: "#fff",
                  fontWeight: 600,
                  py: 1.5,
                  "&:hover": {
                    backgroundColor: "#1b5e20",
                  },
                }}
              >
                {loading ? "Posting Job..." : "Post Job"}
              </Button>
              {loading && (
                <CircularProgress
                  size={24}
                  sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    marginTop: "-12px",
                    marginLeft: "-12px",
                    color: "#2e7d32",
                  }}
                />
              )}
            </Box>
          </form>
        </Card>
      </Container>
    </Box>
  )
}

export default AddJob
