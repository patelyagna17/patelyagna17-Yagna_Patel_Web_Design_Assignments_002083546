// /** @jsx jsx */
// /** @jsxRuntime classic */
// import { jsx } from '@emotion/react'
// import { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchJobs } from '../redux/actions/jobActions';
// import { Card, Typography, CircularProgress } from '@mui/material';

// const styles = () => ({
//   margin: '0 auto',
//   maxWidth: '800px',
//   padding: '20px',
//   backgroundColor: '#f0f0f0',
//   borderRadius: '8px',
//   boxShadow: '0 2px 4px rgba(0,0,0,0.1)',

//   '.jobCard': {
//     borderBottom: '1px solid #ccc',
//     padding: '20px',
//     borderRadius: '15px',
//     marginBottom: '25px',
//     '&:last-child': {
//       border: 'none',
//       paddingBottom: '0',
//       marginBottom: '0',
//     },
//   },
//   '.jobTitle': {
//     fontSize: '24px',
//     color: '#333',
//     margin: '0 0 10px 0',
//   },
//   '.jobDescription': {
//     fontSize: '16px',
//     color: '#666',
//     margin: '0 0 10px 0',
//   },
//   '.jobUpdated': {
//     fontSize: '14px',
//     color: '#999',
//     margin: '0 0 10px 0',
//   },
//   '.applyLink': {
//     fontSize: '16px',
//     color: '#007bff',
//     textDecoration: 'none',
//     '&:hover': {
//       textDecoration: 'underline',
//     },
//   },
//   '.loadingContainer': {
//     display: 'flex',
//     justifyContent: 'center',
//     padding: '40px 0',
//   },
//   '.error': {
//     color: 'red',
//     textAlign: 'center',
//     padding: '20px 0',
//   }
// });

// function JobPostings() {
//   const dispatch = useDispatch();
//   const { jobs, loading, error } = useSelector(state => state.jobs);

//   useEffect(() => {
//     dispatch(fetchJobs());
//   }, [dispatch]);

//   if (loading) {
//     return (
//       <div css={styles()}>
//         <div className="loadingContainer">
//           <CircularProgress />
//         </div>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div css={styles()}>
//         <Typography className="error">{error}</Typography>
//       </div>
//     );
//   }

//   return (
//     <div className="job-listings" css={styles()}>
//       <Typography variant='h4'>Job Listings</Typography>
//       <div>
//         {jobs.length > 0 ? (
//           jobs.map((job) => (
//             <Card key={job._id} className='jobCard'>
//               <h2 className='jobTitle'>{job.jobTitle}</h2>
//               <Typography className='jobDescription'>Job Description: {job.description}</Typography>
//               <Typography className='jobDescription'>Company: {job.companyName}</Typography>
//               <Typography className='jobDescription'>Salary: ${job.salary.toLocaleString()}</Typography>
//               <Typography className='jobUpdated'>
//                 Posted: {new Date(job.createdAt).toLocaleDateString()}
//               </Typography>
//               <a href="https://example.com/apply/" className='applyLink'>Apply Here</a>
//             </Card>
//           ))
//         ) : (
//           <Typography textAlign="center" color="textSecondary" sx={{ mt: 2 }}>
//             No job listings available
//           </Typography>
//         )}
//       </div>
//     </div>
//   );
// }

// export default JobbPostings;
"use client"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { fetchJobs } from "../redux/actions/jobActions"
import {
  Box,
  Card,
  CardContent,
  Typography,
  CircularProgress,
  Grid,
  Container,
  Button,
} from "@mui/material"

function JobListings() {
  const dispatch = useDispatch()
  const { jobs, loading, error } = useSelector((state) => state.jobs)

  useEffect(() => {
    dispatch(fetchJobs())
  }, [dispatch])

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "60vh" }}>
        <CircularProgress sx={{ color: "#2e7d32" }} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ textAlign: "center", py: 4 }}>
        <Typography variant="h6" sx={{ color: "#f44336" }}>
          {error}
        </Typography>
      </Box>
    )
  }

  return (
    <Box sx={{ backgroundColor: "#f5fff5", py: 6, minHeight: "100vh" }}>
      <Container maxWidth="lg">
        <Typography variant="h4" sx={{ color: "#1b5e20", fontWeight: "bold", mb: 4, textAlign: "center" }}>
          Job Listings
        </Typography>

        {jobs.length > 0 ? (
          <Grid container spacing={4}>
            {jobs.map((job) => (
              <Grid item xs={12} sm={6} md={4} key={job._id}>
                <Card sx={{ backgroundColor: "#ffffff", borderLeft: "5px solid #2e7d32", height: "100%" }}>
                  <CardContent>
                    <Typography variant="h6" sx={{ color: "#1b5e20", fontWeight: 600, mb: 1 }}>
                      {job.jobTitle}
                    </Typography>
                    <Typography variant="subtitle2" sx={{ color: "#2e7d32", mb: 1 }}>
                      {job.companyName}
                    </Typography>
                    <Typography variant="body2" sx={{ color: "#33691e", mb: 1 }}>
                      {job.description.length > 100
                        ? `${job.description.slice(0, 100)}...`
                        : job.description}
                    </Typography>
                    <Typography variant="body2" sx={{ color: "#4caf50", mb: 1 }}>
                      Salary: ${job.salary.toLocaleString()}
                    </Typography>
                    <Typography variant="caption" sx={{ color: "#757575", display: "block", mb: 2 }}>
                      Posted on: {new Date(job.createdAt).toLocaleDateString()}
                    </Typography>
                    <Button
                      variant="outlined"
                      size="small"
                      href="https://example.com/apply/"
                      target="_blank"
                      sx={{
                        color: "#2e7d32",
                        borderColor: "#2e7d32",
                        "&:hover": {
                          borderColor: "#1b5e20",
                          backgroundColor: "rgba(46, 125, 50, 0.04)",
                        },
                      }}
                    >
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography textAlign="center" sx={{ color: "#2e7d32", mt: 4 }}>
            No job listings available.
          </Typography>
        )}
      </Container>
    </Box>
  )
}

export default JobListings
