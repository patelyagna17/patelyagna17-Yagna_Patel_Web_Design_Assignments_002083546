// // import React from 'react';
// // import { useNavigate } from 'react-router-dom';
// // import axios from 'axios';
// // import { useState } from 'react';
// // import { 
// //   Typography, 
// //   Box, 
// //   TextField, 
// //   Button, 
// //   Container,
// //   FormControl,
// //   InputLabel,
// //   MenuItem,
// //   Select
// // } from '@mui/material';

// // function Register() {
// //   const navigate = useNavigate();
// //   const [formData, setFormData] = useState({
// //     fullName: '',
// //     email: '',
// //     password: '',
// //     type: ''
// //   });
// //   const [error, setError] = useState('');

// //   const handleChange = (e) => {
// //     const { name, value } = e.target;
// //     setFormData(prevState => ({
// //       ...prevState,
// //       [name]: value
// //     }));
// //   };

// //   const onRegister = (e) => {
// //     e.preventDefault();
// //     setError('');

// //     axios.post('http://localhost:3001/user/create', formData)
// //       .then(function (response) {
// //         if(response.data.success) {
// //           alert('Registration successful!');
// //           navigate('/login');
// //         } else {
// //           setError(response.data.message);
// //         }
// //       })
// //       .catch(function (error) {
// //         if (error.response && error.response.data) {
// //           setError(error.response.data.message);
// //         } else {
// //           setError('Registration failed. Please try again.');
// //         }
// //       });
// //   };

// //   return (
// //     <Container maxWidth="sm">
// //       <Box
// //         sx={{
// //           mt: 20,
// //           display: 'flex',
// //           fontFamily: 'Arial, Helvetica, sans-serif',
// //           flexDirection: 'column',
// //           alignItems: 'center',
// //           p: 10,
// //           backgroundColor: 'white',
// //           borderRadius: 2,
// //           boxShadow: '0 3px 5px 2px rgba(0, 0, 0, .3)'
// //         }}
// //       >
// //         <Typography component="h1" variant="h3" sx={{ mb: 2 }}>
// //           Job Portal
// //         </Typography>
// //         <Box component="form" sx={{ mb: 2, width: '100%' }} onSubmit={onRegister}>
// //           <TextField 
// //             label="Full Name" 
// //             name="fullName"
// //             variant="outlined" 
// //             required 
// //             sx={{ mb: 2, width: '100%' }} 
// //             value={formData.fullName} 
// //             onChange={handleChange}
// //           />
// //           <TextField 
// //             label="Email" 
// //             name="email"
// //             type="email"
// //             variant="outlined" 
// //             required 
// //             sx={{ mb: 2, width: '100%' }} 
// //             value={formData.email} 
// //             onChange={handleChange}
// //           />
// //           <TextField 
// //             label="Password" 
// //             name="password"
// //             type="password" 
// //             variant="outlined" 
// //             required 
// //             sx={{ mb: 2, width: '100%' }} 
// //             value={formData.password} 
// //             onChange={handleChange}
// //           />
// //           <FormControl fullWidth sx={{ mb: 2 }}>
// //             <InputLabel id="type-label">Type</InputLabel>
// //             <Select
// //               labelId="type-label"
// //               label="Type"
// //               name="type"
// //               value={formData.type}
// //               onChange={handleChange}
// //               required
// //             >
// //               <MenuItem value="admin">Admin</MenuItem>
// //               <MenuItem value="user">User</MenuItem>
// //             </Select>
// //           </FormControl>
// //           {error && (
// //             <Typography color="error" sx={{ mb: 2 }}>
// //               {error}
// //             </Typography>
// //           )}
// //           <Button 
// //             type="submit" 
// //             variant="contained" 
// //             fullWidth 
// //             sx={{ mt: 1, mb: 2 }}
// //           >
// //             Register
// //           </Button>
// //           <Button 
// //             variant="text" 
// //             fullWidth 
// //             onClick={() => navigate('/login')}
// //           >
// //             Already have an account? Login
// //           </Button>
// //         </Box>
// //       </Box>
// //     </Container>
// //   );
// // }

// // export default Register;

// "use client"
// import { useNavigate } from "react-router-dom"
// import axios from "axios"
// import { useState } from "react"
// import { Typography, Box, TextField, Button, Container, FormControl, InputLabel, MenuItem, Select } from "@mui/material"

// function Register() {
//   const navigate = useNavigate()
//   const [formData, setFormData] = useState({
//     fullName: "",
//     email: "",
//     password: "",
//     type: "",
//   })
//   const [error, setError] = useState("")

//   const handleChange = (e) => {
//     const { name, value } = e.target
//     setFormData((prevState) => ({
//       ...prevState,
//       [name]: value,
//     }))
//   }

//   const onRegister = (e) => {
//     e.preventDefault()
//     setError("")

//     axios
//       .post("http://localhost:3001/user/create", formData)
//       .then((response) => {
//         if (response.data.success) {
//           alert("Registration successful!")
//           navigate("/login")
//         } else {
//           setError(response.data.message)
//         }
//       })
//       .catch((error) => {
//         if (error.response && error.response.data) {
//           setError(error.response.data.message)
//         } else {
//           setError("Registration failed. Please try again.")
//         }
//       })
//   }

//   return (
//     <Container maxWidth="sm">
//       <Box
//         sx={{
//           mt: 20,
//           display: "flex",
//           fontFamily: "Arial, Helvetica, sans-serif",
//           flexDirection: "column",
//           alignItems: "center",
//           p: 10,
//           backgroundColor: "#e8f5e9",
//           borderRadius: 2,
//           boxShadow: "0 3px 5px 2px rgba(0, 0, 0, .3)",
//         }}
//       >
//         <Typography component="h1" variant="h3" sx={{ mb: 2, color: "#1b5e20" }}>
//           Job Portal
//         </Typography>
//         <Box component="form" sx={{ mb: 2, width: "100%" }} onSubmit={onRegister}>
//           <TextField
//             label="Full Name"
//             name="fullName"
//             variant="outlined"
//             required
//             sx={{
//               mb: 2,
//               width: "100%",
//               "& .MuiOutlinedInput-root": {
//                 "&.Mui-focused fieldset": {
//                   borderColor: "#2e7d32",
//                 },
//               },
//               "& .MuiInputLabel-root.Mui-focused": {
//                 color: "#2e7d32",
//               },
//             }}
//             value={formData.fullName}
//             onChange={handleChange}
//           />
//           <TextField
//             label="Email"
//             name="email"
//             type="email"
//             variant="outlined"
//             required
//             sx={{
//               mb: 2,
//               width: "100%",
//               "& .MuiOutlinedInput-root": {
//                 "&.Mui-focused fieldset": {
//                   borderColor: "#2e7d32",
//                 },
//               },
//               "& .MuiInputLabel-root.Mui-focused": {
//                 color: "#2e7d32",
//               },
//             }}
//             value={formData.email}
//             onChange={handleChange}
//           />
//           <TextField
//             label="Password"
//             name="password"
//             type="password"
//             variant="outlined"
//             required
//             sx={{
//               mb: 2,
//               width: "100%",
//               "& .MuiOutlinedInput-root": {
//                 "&.Mui-focused fieldset": {
//                   borderColor: "#2e7d32",
//                 },
//               },
//               "& .MuiInputLabel-root.Mui-focused": {
//                 color: "#2e7d32",
//               },
//             }}
//             value={formData.password}
//             onChange={handleChange}
//           />
//           <FormControl
//             fullWidth
//             sx={{
//               mb: 2,
//               "& .MuiOutlinedInput-root": {
//                 "&.Mui-focused fieldset": {
//                   borderColor: "#2e7d32",
//                 },
//               },
//               "& .MuiInputLabel-root.Mui-focused": {
//                 color: "#2e7d32",
//               },
//             }}
//           >
//             <InputLabel id="type-label">Type</InputLabel>
//             <Select
//               labelId="type-label"
//               label="Type"
//               name="type"
//               value={formData.type}
//               onChange={handleChange}
//               required
//             >
//               <MenuItem value="admin">Admin</MenuItem>
//               <MenuItem value="user">User</MenuItem>
//             </Select>
//           </FormControl>
//           {error && (
//             <Typography color="error" sx={{ mb: 2 }}>
//               {error}
//             </Typography>
//           )}
//           <Button
//             type="submit"
//             variant="contained"
//             fullWidth
//             sx={{
//               mt: 1,
//               mb: 2,
//               backgroundColor: "#2e7d32",
//               "&:hover": {
//                 backgroundColor: "#1b5e20",
//               },
//             }}
//           >
//             Register
//           </Button>
//           <Button variant="text" fullWidth onClick={() => navigate("/login")} sx={{ color: "#2e7d32" }}>
//             Already have an account? Login
//           </Button>
//         </Box>
//       </Box>
//     </Container>
//   )
// }

// export default Register

"use client"
import { useNavigate } from "react-router-dom"
import axios from "axios"
import { useState } from "react"
import { Typography, Box, TextField, Button, Container, FormControl, InputLabel, MenuItem, Select } from "@mui/material"

function Register() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    type: "",
  })
  const [error, setError] = useState("")

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  const onRegister = (e) => {
    e.preventDefault()
    setError("")

    axios
      .post("http://localhost:3001/user/create", formData)
      .then((response) => {
        if (response.data.success) {
          alert("Registration successful!")
          navigate("/login")
        } else {
          setError(response.data.message)
        }
      })
      .catch((error) => {
        if (error.response && error.response.data) {
          setError(error.response.data.message)
        } else {
          setError("Registration failed. Please try again.")
        }
      })
  }

  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          mt: 20,
          display: "flex",
          fontFamily: "Arial, Helvetica, sans-serif",
          flexDirection: "column",
          alignItems: "center",
          p: 10,
          backgroundColor: "#e8f5e9",
          borderRadius: 2,
          boxShadow: "0 3px 5px 2px rgba(0, 0, 0, .3)",
        }}
      >
        <Typography component="h1" variant="h3" sx={{ mb: 2, color: "#1b5e20" }}>
          Job Portal
        </Typography>
        <Box component="form" sx={{ mb: 2, width: "100%" }} onSubmit={onRegister}>
          <TextField
            label="Full Name"
            name="fullName"
            variant="outlined"
            required
            sx={{
              mb: 2,
              width: "100%",
              "& .MuiOutlinedInput-root": {
                "&.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
              },
              "& .MuiInputLabel-root.Mui-focused": {
                color: "#2e7d32",
              },
            }}
            value={formData.fullName}
            onChange={handleChange}
          />
          <TextField
            label="Email"
            name="email"
            type="email"
            variant="outlined"
            required
            sx={{
              mb: 2,
              width: "100%",
              "& .MuiOutlinedInput-root": {
                "&.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
              },
              "& .MuiInputLabel-root.Mui-focused": {
                color: "#2e7d32",
              },
            }}
            value={formData.email}
            onChange={handleChange}
          />
          <TextField
            label="Password"
            name="password"
            type="password"
            variant="outlined"
            required
            sx={{
              mb: 2,
              width: "100%",
              "& .MuiOutlinedInput-root": {
                "&.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
              },
              "& .MuiInputLabel-root.Mui-focused": {
                color: "#2e7d32",
              },
            }}
            value={formData.password}
            onChange={handleChange}
          />
          <FormControl
            fullWidth
            sx={{
              mb: 2,
              "& .MuiOutlinedInput-root": {
                "&.Mui-focused fieldset": {
                  borderColor: "#2e7d32",
                },
              },
              "& .MuiInputLabel-root.Mui-focused": {
                color: "#2e7d32",
              },
            }}
          >
            <InputLabel id="type-label">Type</InputLabel>
            <Select
              labelId="type-label"
              label="Type"
              name="type"
              value={formData.type}
              onChange={handleChange}
              required
            >
              <MenuItem value="admin">Admin</MenuItem>
              <MenuItem value="user">User</MenuItem>
            </Select>
          </FormControl>
          {error && (
            <Typography color="error" sx={{ mb: 2 }}>
              {error}
            </Typography>
          )}
          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{
              mt: 1,
              mb: 2,
              backgroundColor: "#2e7d32",
              "&:hover": {
                backgroundColor: "#1b5e20",
              },
            }}
          >
            Register
          </Button>
          <Button variant="text" fullWidth onClick={() => navigate("/login")} sx={{ color: "#2e7d32" }}>
            Already have an account? Login
          </Button>
        </Box>
      </Box>
    </Container>
  )
}

export default Register

