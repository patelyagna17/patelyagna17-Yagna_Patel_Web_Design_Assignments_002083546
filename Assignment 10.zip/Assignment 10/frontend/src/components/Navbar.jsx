// import React from 'react';
// import { Link } from 'react-router-dom';
// import { AppBar, Toolbar, Button, Box } from '@mui/material';

// function Navbar({ setIsLoggedIn, userRole }) {
//   const handleLogout = () => {
//     setIsLoggedIn(false);
//     localStorage.removeItem('userRole');
//     localStorage.removeItem('isLoggedIn');
//   };

//   return (
//     <AppBar position="static">
//       <Toolbar>
//         <Box sx={{ flexGrow: 1, display: 'flex', gap: 2 }}>
//           {userRole === 'admin' ? (
//             // Admin Navigation
//             <>
//               <Button color="inherit" component={Link} to="/employees">
//                 Employees
//               </Button>
//               <Button color="inherit" component={Link} to="/addjobs">
//                 Add Jobs
//               </Button>
//             </>
//           ) : (
//             // Employee Navigation
//             <>
//               <Button color="inherit" component={Link} to="/home">
//                 Home
//               </Button>
//               <Button color="inherit" component={Link} to="/about">
//                 About
//               </Button>
//               <Button color="inherit" component={Link} to="/contact">
//                 Contact
//               </Button>
//               <Button color="inherit" component={Link} to="/companies">
//                 Companies
//               </Button>
//               <Button color="inherit" component={Link} to="/joblistings">
//                 Job Listings
//               </Button>
//             </>
//           )}
//         </Box>
//         <Button color="inherit" onClick={handleLogout}>
//           Logout
//         </Button>
//       </Toolbar>
//     </AppBar>
//   );
// }

// export default Navbar;

"use client"
import { Link } from "react-router-dom"
import { AppBar, Toolbar, Button, Box, Typography, Container } from "@mui/material"
import HomeIcon from "@mui/icons-material/Home"
import InfoIcon from "@mui/icons-material/Info"
import ContactSupportIcon from "@mui/icons-material/ContactSupport"
import BusinessIcon from "@mui/icons-material/Business"
import WorkIcon from "@mui/icons-material/Work"
import PeopleIcon from "@mui/icons-material/People"
import AddCircleIcon from "@mui/icons-material/AddCircle"
import LogoutIcon from "@mui/icons-material/Logout"

function Navbar({ setIsLoggedIn, userRole }) {
  const handleLogout = () => {
    setIsLoggedIn(false)
    localStorage.removeItem("userRole")
    localStorage.removeItem("isLoggedIn")
  }

  return (
    <AppBar
      position="static"
      sx={{
        backgroundColor: "#1b5e20",
        boxShadow: "0 3px 5px rgba(0,0,0,0.2)",
      }}
    >
      <Container maxWidth="xl">
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          <Typography
            variant="h5"
            component="div"
            sx={{
              fontWeight: "bold",
              color: "#ffffff",
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <WorkIcon /> Growth
          </Typography>

          <Box sx={{ display: "flex", gap: 1 }}>
            {userRole === "admin" ? (
              // Admin Navigation
              <>
                <Button
                  color="inherit"
                  component={Link}
                  to="/employees"
                  startIcon={<PeopleIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Employees
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/addjobs"
                  startIcon={<AddCircleIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Add Jobs
                </Button>
              </>
            ) : (
              // Employee Navigation
              <>
                <Button
                  color="inherit"
                  component={Link}
                  to="/home"
                  startIcon={<HomeIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Home
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/about"
                  startIcon={<InfoIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  About
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/contact"
                  startIcon={<ContactSupportIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Contact
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/companies"
                  startIcon={<BusinessIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Companies
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/joblistings"
                  startIcon={<WorkIcon />}
                  sx={{
                    borderRadius: "8px",
                    padding: "6px 16px",
                    "&:hover": {
                      backgroundColor: "rgba(255,255,255,0.1)",
                    },
                  }}
                >
                  Job Listings
                </Button>
              </>
            )}
          </Box>

          <Button
            color="inherit"
            onClick={handleLogout}
            startIcon={<LogoutIcon />}
            sx={{
              backgroundColor: "#4caf50",
              borderRadius: "8px",
              padding: "6px 16px",
              "&:hover": {
                backgroundColor: "#388e3c",
              },
            }}
          >
            Logout
          </Button>
        </Toolbar>
      </Container>
    </AppBar>
  )
}

export default Navbar

