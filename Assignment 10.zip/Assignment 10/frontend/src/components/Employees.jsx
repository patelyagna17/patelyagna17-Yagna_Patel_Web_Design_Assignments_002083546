// /** @jsx jsx */
// /** @jsxRuntime classic */
// import { jsx } from '@emotion/react';
// import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchEmployees } from '../redux/actions/employeeActions';
// import {
//   Card,
//   Typography,
//   CircularProgress,
//   Box
// } from '@mui/material';

// const styles = {
//   container: {
//     margin: '0 auto',
//     maxWidth: '800px',
//     padding: '20px',
//     backgroundColor: '#f0f0f0',
//     borderRadius: '8px',
//     boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
//   },
//   employeeCard: {
//     borderBottom: '1px solid #ccc',
//     padding: '20px',
//     borderRadius: '15px',
//     marginBottom: '25px',
//     backgroundColor: '#fff',
//     '&:last-child': {
//       border: 'none',
//       paddingBottom: '0',
//       marginBottom: '0',
//     },
//   },
//   title: {
//     fontSize: '24px',
//     color: '#333',
//     margin: '0 0 20px 0',
//   },
//   employeeInfo: {
//     fontSize: '16px',
//     color: '#666',
//     margin: '10px 0',
//   },
//   employeeType: {
//     fontSize: '14px',
//     color: '#999',
//     margin: '10px 0',
//   },
//   employeeHeader: {
//     display: 'flex',
//     alignItems: 'center',
//     marginBottom: '10px',
//   },
//   loadingContainer: {
//     display: 'flex',
//     justifyContent: 'center',
//     alignItems: 'center',
//     minHeight: '100vh',
//   },
//   errorMessage: {
//     color: '#ff0000',
//     textAlign: 'center',
//     margin: '20px 0',
//   }
// };

// function Employees() {
//   const dispatch = useDispatch();
//   const { employees, loading, error } = useSelector(state => state.employees);

//   useEffect(() => {
//     dispatch(fetchEmployees());
//   }, [dispatch]);

//   if (loading) {
//     return (
//       <Box css={styles.loadingContainer}>
//         <CircularProgress />
//       </Box>
//     );
//   }

//   if (error) {
//     return (
//       <Box css={styles.loadingContainer}>
//         <Typography css={styles.errorMessage}>{error}</Typography>
//       </Box>
//     );
//   }

//   return (
//     <div css={styles.container}>
//       <Typography variant="h4" css={styles.title}>Employees</Typography>
//       <div>
//         {employees.map((user) => (
//           <Card key={user.email} css={styles.employeeCard}>
//             <div css={styles.employeeHeader}>
//               <h2 css={styles.title}>{user.fullName}</h2>
//             </div>
//             <Typography css={styles.employeeInfo}>
//               Email: {user.email}
//             </Typography>
//             <Typography css={styles.employeeType}>
//               Role: {user.type}
//             </Typography>
//           </Card>
//         ))}
//         {employees.length === 0 && (
//           <Typography css={styles.employeeInfo} style={{ textAlign: 'center' }}>
//             No employees found
//           </Typography>
//         )}
//       </div>
//     </div>
//   );
// }

// export default Employees;

"use client"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { fetchEmployees } from "../redux/actions/employeeActions"
import {
  Card,
  Typography,
  CircularProgress,
  Box,
  Grid,
  Container,
} from "@mui/material"

function Employees() {
  const dispatch = useDispatch()
  const { employees, loading, error } = useSelector((state) => state.employees)

  useEffect(() => {
    dispatch(fetchEmployees())
  }, [dispatch])

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
        }}
      >
        <CircularProgress sx={{ color: "#2e7d32" }} />
      </Box>
    )
  }

  if (error) {
    return (
      <Box sx={{ textAlign: "center", py: 4 }}>
        <Typography variant="h6" sx={{ color: "#f44336" }}>
          {error}
        </Typography>
      </Box>
    )
  }

  return (
    <Box sx={{ backgroundColor: "#f5fff5", minHeight: "100vh", py: 6 }}>
      <Container maxWidth="md">
        <Typography
          variant="h4"
          sx={{
            color: "#1b5e20",
            fontWeight: "bold",
            textAlign: "center",
            mb: 4,
          }}
        >
          Employees
        </Typography>

        {employees.length > 0 ? (
          <Grid container spacing={3}>
            {employees.map((user) => (
              <Grid item xs={12} sm={6} key={user.email}>
                <Card
                  sx={{
                    backgroundColor: "#ffffff",
                    borderLeft: "5px solid #2e7d32",
                    p: 3,
                    borderRadius: 2,
                    boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
                  }}
                >
                  <Typography variant="h6" sx={{ color: "#1b5e20", fontWeight: 600, mb: 1 }}>
                    {user.fullName}
                  </Typography>
                  <Typography variant="body2" sx={{ color: "#33691e", mb: 0.5 }}>
                    Email: {user.email}
                  </Typography>
                  <Typography variant="body2" sx={{ color: "#4caf50" }}>
                    Role: {user.type}
                  </Typography>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography textAlign="center" sx={{ color: "#2e7d32", mt: 2 }}>
            No employees found.
          </Typography>
        )}
      </Container>
    </Box>
  )
}

export default Employees
