// import React, { useState } from 'react';
// import { Typography, Box, TextField, Button, Grid } from '@mui/material';

// function Contact() {
//   const [contactForm, setContactForm] = useState({
//     name: '',
//     email: '',
//     subject: '',
//     message: '',
//   });

//   const handleChange = event => setContactForm({
//     ...contactForm, 
//     [event.target.name]: event.target.value,
//   });
  

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log(contactForm);
//     alert('Message sent! We will get back to you as soon as possible.');
//     // Reset form after submission
//     setContactForm({
//       name: '',
//       email: '',
//       subject: '',
//       message: '',
//     });
//   };

//   return (
//     <Box sx={{ flexGrow: 1, padding: 2 }}>
//       <Typography variant="h2" gutterBottom>
//         Contact Us
//       </Typography>
      
//       {/* Contact Information */}
//       <Grid container spacing={2} sx={{ mb: 4 }}>
//         <Grid item xs={12} md={4}>
//           <Typography variant="h6">Our Address</Typography>
//           <Typography variant="body1">59 Bynner Street, Boston</Typography>
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <Typography variant="h6">Call Us</Typography>
//           <Typography variant="body1">+1 (617) 934-9276</Typography>
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <Typography variant="h6">Email Us</Typography>
//           <Typography variant="body1">support@jobportal.com</Typography>
//         </Grid>
//       </Grid>

//       {/* Contact Form */}
//       <Box component="form" noValidate autoComplete="off" onSubmit={handleSubmit}>
//         <Grid container spacing={2}>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               fullWidth
//               label="Name"
//               name="name"
//               value={contactForm.name}
//               onChange={handleChange}
//               required
//             />
//           </Grid>
//           <Grid item xs={12} sm={6}>
//             <TextField
//               fullWidth
//               label="Email"
//               name="email"
//               value={contactForm.email}
//               onChange={handleChange}
//               required
//             />
//           </Grid>
       
//           <Grid item xs={12}>
//             <TextField
//               fullWidth
//               label="Message"
//               name="message"
//               value={contactForm.message}
//               multiline
//               rows={5}
//               onChange={handleChange}
//               required
//             />
//           </Grid>
//           <Grid item xs={12}>
//             <Button type="submit" variant="contained" color="primary">
//               Send 
//             </Button>
//           </Grid>
//         </Grid>
//       </Box>
//     </Box>
//   );
// }

// export default Contact;
"use client"

import { useState } from "react"
import { Typography, Box, TextField, Button, Grid, Paper } from "@mui/material"

function Contact() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleChange = (event) =>
    setContactForm({
      ...contactForm,
      [event.target.name]: event.target.value,
    })

  const handleSubmit = (event) => {
    event.preventDefault()
    console.log(contactForm)
    alert("Thank you for reaching out! Our team will respond shortly.")
    setContactForm({
      name: "",
      email: "",
      subject: "",
      message: "",
    })
  }

  return (
    <Box sx={{ flexGrow: 1, padding: 4, backgroundColor: "#f5fff5", minHeight: "100vh" }}>
      <Typography variant="h2" sx={{ color: "#1b5e20", fontWeight: "bold", textAlign: "center", mb: 4 }}>
        Get in Touch
      </Typography>

      {/* Contact Information */}
      <Grid container spacing={3} sx={{ mb: 5, maxWidth: "900px", mx: "auto" }}>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 2, backgroundColor: "#e8f5e9" }}>
            <Typography variant="h6" sx={{ color: "#2e7d32" }}>
              Visit Us
            </Typography>
            <Typography variant="body2" sx={{ color: "#33691e" }}>
              2959 washington Street, Boston, MA
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 2, backgroundColor: "#e8f5e9" }}>
            <Typography variant="h6" sx={{ color: "#2e7d32" }}>
              Call Us
            </Typography>
            <Typography variant="body2" sx={{ color: "#33691e" }}>
              +1 (657) 954-9326
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={2} sx={{ p: 2, backgroundColor: "#e8f5e9" }}>
            <Typography variant="h6" sx={{ color: "#2e7d32" }}>
              Email
            </Typography>
            <Typography variant="body2" sx={{ color: "#33691e" }}>
              support@growth.com
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Contact Form */}
      <Box
        component="form"
        noValidate
        autoComplete="off"
        onSubmit={handleSubmit}
        sx={{ maxWidth: "900px", mx: "auto" }}
      >
        <Typography variant="h5" sx={{ color: "#2e7d32", mb: 2 }}>
          We'd love to hear from you
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Full Name"
              name="name"
              value={contactForm.name}
              onChange={handleChange}
              required
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#2e7d32",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Email Address"
              name="email"
              value={contactForm.email}
              onChange={handleChange}
              required
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#2e7d32",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Subject"
              name="subject"
              value={contactForm.subject}
              onChange={handleChange}
              required
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#2e7d32",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Your Message"
              name="message"
              value={contactForm.message}
              multiline
              rows={5}
              onChange={handleChange}
              required
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused fieldset": {
                    borderColor: "#2e7d32",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "#2e7d32",
                },
              }}
            />
          </Grid>
          <Grid item xs={12} sx={{ textAlign: "right" }}>
            <Button
              type="submit"
              variant="contained"
              sx={{
                backgroundColor: "#2e7d32",
                px: 4,
                py: 1.5,
                fontWeight: 600,
                "&:hover": {
                  backgroundColor: "#1b5e20",
                },
              }}
            >
              Send Message
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Box>
  )
}

export default Contact
