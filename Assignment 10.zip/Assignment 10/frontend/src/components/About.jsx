// import React from 'react';
// import { Typography, Box, Card, CardContent, Grid } from '@mui/material';

// function About() {
//   return (
//     <Box sx={{ flexGrow: 1, padding: 2 }}>
//       {/* About Us Section */}
//       <Typography variant="h2" >
//         About JobPortal
//       </Typography>

//       {/* Our Story */}
//       <Typography variant="h5" sx={{ my: 2}}>
//         Our Story
//       </Typography>
//       <Typography variant="body1" >
//       Launched in 2024, JobPortal was established with the mission to streamline the job search process and bridge the gap between skilled professionals and rewarding career opportunities. Our rapid growth is a testament to our dedication to matching job seekers with their ideal roles and helping companies find top-tier talent.
//       </Typography>

//       {/* Mission and Vision */}
//       <Typography variant="h5" sx={{ my: 2 }}>
//         Our Mission and Vision
//       </Typography>
//       <Typography variant="body1" >
//       Our mission is to empower job seekers and employers by making meaningful connections. We envision a world where every job search begins and ends successfully on JobPortal, seamlessly bridging the gap between talent and opportunity.
//       </Typography>

//       {/* Meet the Team */}
//       <Typography variant="h5" sx={{ my: 2 }}>
//         our Team
//       </Typography>
//       <Grid container spacing={2}>
//         {[
//           { name: 'Praktan Kini', role: 'CEO & Founder' },
//           { name: 'Hareshwar Patil', role: 'CTO & Co-Founder' },
//           { name: 'Sunny Patil', role: 'Head of Marketing' },
//         ].map((member, index) => (
//           <Grid item xs={12} sm={6} md={4} key={index}>
//             <Card>
//               <CardContent>
//                 <Typography variant="h6" component="div">
//                   {member.name}
//                 </Typography>
//                 <Typography variant="body2">
//                   {member.role}
//                 </Typography>
//               </CardContent>
//             </Card>
//           </Grid>
//         ))}
//       </Grid>

//       {/* Success Stories */}
//       <Typography variant="h5" sx={{ my: 2 }}>
//         Success Stories
//       </Typography>
//       <Typography variant="body1" gutterBottom>
//       Samuel.S ., Product Manager at TechInnovate, proudly shares that we've facilitated over 50,000 job seekers in finding their ideal positions and enabled 5,000 companies to acquire outstanding talent. Become a part of our winning narrative today.
//       </Typography>
//     </Box>
//   );
// }

// export default About;
import { Typography, Box, Card, CardContent, Grid, Divider } from "@mui/material"

function About() {
  const teamMembers = [
    { name: "Yagna Patel", role: "CEO & Founder" },
    { name: "Maharishi Patel", role: "CTO & Co-Founder" },
    { name: "Rushikesh Patel", role: "Head of Marketing" }
  ]

  return (
    <Box sx={{ flexGrow: 1, padding: 4, backgroundColor: "#f5fff5", minHeight: "100vh" }}>
      {/* Header */}
      <Typography variant="h2" sx={{ color: "#1b5e20", fontWeight: "bold", textAlign: "center", mb: 4 }}>
        About Growth
      </Typography>

      {/* Our Story */}
      <Box sx={{ maxWidth: "900px", mx: "auto", mb: 5 }}>
        <Typography variant="h5" sx={{ color: "#2e7d32", mb: 1 }}>
          Our Story
        </Typography>
        <Typography variant="body1" sx={{ color: "#33691e" }}>
        Established in 2023, Growth set out to transform the hiring experience by bridging the gap between ambitious professionals and meaningful career opportunities. Our rapid growth is a reflection of our commitment to simplifying the job search process while enabling companies to connect with exceptional talent.
        </Typography>
      </Box>

      {/* Mission and Vision */}
      <Box sx={{ maxWidth: "900px", mx: "auto", mb: 5 }}>
        <Typography variant="h5" sx={{ color: "#2e7d32", mb: 1 }}>
          Our Mission & Vision
        </Typography>
        <Typography variant="body1" sx={{ color: "#33691e" }}>
          Our mission is to enable job seekers and employers to connect seamlessly. We envision a world where everyone
          finds their dream opportunity right here on JobPortal—turning potential into progress.
        </Typography>
      </Box>

      {/* Meet the Team */}
      <Box sx={{ maxWidth: "900px", mx: "auto", mb: 5 }}>
        <Typography variant="h5" sx={{ color: "#2e7d32", mb: 2 }}>
          Meet the Team
        </Typography>
        <Grid container spacing={3}>
          {teamMembers.map((member, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card
                elevation={3}
                sx={{
                  backgroundColor: "#e8f5e9",
                  borderLeft: "5px solid #2e7d32",
                  p: 2,
                  height: "100%"
                }}
              >
                <CardContent>
                  <Typography variant="h6" sx={{ color: "#1b5e20", fontWeight: 600 }}>
                    {member.name}
                  </Typography>
                  <Typography variant="body2" sx={{ color: "#2e7d32", mt: 0.5 }}>
                    {member.role}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Success Stories */}
      <Box sx={{ maxWidth: "900px", mx: "auto" }}>
        <Typography variant="h5" sx={{ color: "#2e7d32", mb: 1 }}>
          Success Stories
        </Typography>
        <Typography variant="body1" sx={{ color: "#33691e" }}>
          “Thanks to JobPortal, over 50,000 job seekers have found roles that match their goals and passions, while 5,000+
          companies have hired exceptional talent effortlessly. Join our community and be part of our success story.”
        </Typography>
      </Box>
    </Box>
  )
}

export default About
