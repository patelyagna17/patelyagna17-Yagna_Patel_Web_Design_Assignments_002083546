# React Job Portal Assignment 10

## Overview
The React Job Portal is a cutting-edge web application meticulously crafted to streamline the connection between job seekers and employers. Leveraging React and Redux for robust state management, Material UI for a sleek design, and a Node.js backend, this portal offers role-based access control and a comprehensive suite of features tailored for both job seekers and administrators.

## Key Features
- **User Authentication**: Secure login with role-based access (Admin/User)
- **Role-Based Navigation**: Customized views and permissions for admins and regular users
- **Job Management**: Admins can effortlessly post and manage job listings
- **Dynamic Job Listings**: Users can seamlessly browse available job positions
- **Employee Management**: Admin dashboard for comprehensive employee management
- **Company Showcase**: An engaging gallery of companies with logos and detailed information
- **Redux State Management**: Centralized state management for auth, jobs, and users
- **Responsive Design**: Material UI components ensuring seamless cross-device compatibility

## Technical Stack
- **Frontend**: 
  - React
  - Redux + Redux Thunk
  - Material UI
  - Axios
  - Emotion CSS
- **Backend**: 
  - Node.js
  - Express
  - MongoDB
  - Mongoose
  - bcrypt
  - JWT Authentication

## Project Structure

```
backend/
├── controllers/
│   ├── authController.js     # Authentication logic
│   ├── companyController.js  # Company management
│   ├── jobController.js      # Job posting management
│   └── userControllers.js    # User management
├── models/
│   ├── Jobs.js              # Job schema
│   └── User.js              # User schema
├── routes/
│   ├── authRoutes.js        # Auth endpoints
│   ├── companyRoute.js      # Company endpoints
│   ├── jobRoutes.js         # Job endpoints
│   └── userRoutes.js        # User endpoints
├── images/                   # Uploaded images
├── server.js
└── package.json

frontend/
├── src/
│   ├── components/
│   │   ├── About.jsx
│   │   ├── AddJob.jsx       # Admin job creation
│   │   ├── Companies.jsx
│   │   ├── Contact.jsx
│   │   ├── Employees.jsx    # Admin employee management
│   │   ├── Footer.jsx
│   │   ├── Home.jsx
│   │   ├── JobListings.jsx
│   │   ├── Login.jsx
│   │   ├── Navbar.jsx
│   │   └── Register.jsx
│   ├── redux/
│   │   ├── actions/
│   │   │   ├── authActions.js
│   │   │   ├── companyActions.js
│   │   │   ├── employeeActions.js
│   │   │   └── jobActions.js
│   │   ├── reducers/
│   │   │   ├── authReducer.js
│   │   │   ├── companyReducer.js
│   │   │   ├── employeeReducer.js
│   │   │   ├── jobReducer.js
│   │   │   └── index.js
│   │   └── store.js
│   ├── App.jsx
│   └── index.js
```

## API Endpoints

### Authentication
```
POST /auth/login
- Login user with email/password
- Returns user role and auth token
```

### User Management
```
POST /user/create
- Register new user
- Body: { fullName, email, password, type }

GET /user/getAll
- Get all users (Admin only)
- Returns list of users with details

PUT /user/edit
- Update user details
- Query: email
- Body: { fullName, password }

DELETE /user/delete
- Delete user
- Query: email
```

### Job Management
```
POST /create/job
- Create new job listing (Admin only)
- Body: { companyName, jobTitle, description, salary }

GET /create/getAll
- Get all job listings
- Returns list of available jobs
```

## Redux Implementation

### Store Structure
```javascript
{
  auth: {
    isLoggedIn: boolean,
    userRole: string,
    loading: boolean,
    error: string
  },
  jobs: {
    jobs: array,
    loading: boolean,
    error: string
  },
  employees: {
    employees: array,
    loading: boolean,
    error: string
  }
}
```

### Available Actions
```javascript
// Auth Actions
login(credentials)
register(userData)
logout()

// Job Actions
createJob(jobData)
fetchJobs()

// Employee Actions
fetchEmployees()
```

## Role-Based Access
- **Admin Users**:
  - Access to employee management
  - Can create job listings
  - Full CRUD operations on users
- **Regular Users**:
  - View job listings
  - Access company information
  - Update own profile

## Running the Application

### Backend Setup
```bash
cd backend
npm install
nodemon start
# Server runs on http://localhost:3001
```

### Frontend Setup
```bash
cd frontend
npm install
npm start
# Application runs on http://localhost:3000
```

## Environment Variables
```env
MONGODB_URI=mongodb://localhost:27017/jobportal
PORT=3001
JWT_SECRET=your_jwt_secret
```

## Error Handling
- All API endpoints return consistent error responses
- Redux actions handle and display errors appropriately
- Form validations on both frontend and backend

## Future Enhancements
- Job application tracking
- Advanced search and filtering
- Email notifications
- Profile image upload
- Job categories and tags